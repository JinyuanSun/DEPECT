import time

time.sleep(1)
print("hi")
